argc and argv lessons
