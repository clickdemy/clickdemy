static lib lessons
