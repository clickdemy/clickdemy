More lessons on Pointers, Arrays and Strings
