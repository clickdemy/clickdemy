Structure and typedef lessons
