#ifndef FILE_MACRO
#define FILE_MACRO
#define SIZE 1024

#endif
