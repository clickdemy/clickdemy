Deep dive into pointers
