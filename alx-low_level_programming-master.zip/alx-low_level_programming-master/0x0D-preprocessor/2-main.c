#include <stdio.h>
/**
 * main - check the codes for the Holberton School students
 * Return: Always 0
 */
int main(void)
{
printf("%s\n", __FILE__);
return (0);
}
