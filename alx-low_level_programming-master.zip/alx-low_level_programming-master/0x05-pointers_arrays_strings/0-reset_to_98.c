#include "main.h"

/**
* reset_to_98 - resets the value of the variable.
* it is pointing to to 98.
* @n: argument to the function.
* Description: print out the required result.
* Return: return void.
*/

void reset_to_98(int *n)
{
	 *n = 98;
}
