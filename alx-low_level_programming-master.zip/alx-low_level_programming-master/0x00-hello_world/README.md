this is a C hello world README
