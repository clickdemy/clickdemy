This is for 0x04. C - More functions, more nested loops project
