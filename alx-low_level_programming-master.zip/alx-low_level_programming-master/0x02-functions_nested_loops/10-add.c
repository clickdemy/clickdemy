#include "main.h"

/**
 * add - returns sum of parameters
 * @a: int type
 * @b: int typr
 * Return: 0
 */

int add(int a, int b)

{

	return (a + b);

}
