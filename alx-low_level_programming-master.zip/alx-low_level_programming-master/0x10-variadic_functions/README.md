Variadic functions lessons
