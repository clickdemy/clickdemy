deep dive into malloc
