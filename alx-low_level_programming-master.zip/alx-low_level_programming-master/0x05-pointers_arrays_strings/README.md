Lesson on Arrays, Pointers & Strings
