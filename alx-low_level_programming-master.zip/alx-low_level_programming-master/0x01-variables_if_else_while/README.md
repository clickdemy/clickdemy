This is assignment number 2 in low level programming
