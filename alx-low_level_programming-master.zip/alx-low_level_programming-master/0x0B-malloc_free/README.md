Malloc stands for memory-allocation. Once used to allocate memory, there is no default way to free up memory space after execution of a program, which is why we use the command 'free'. Hence the topic 0x0B-malloc_free.

